Title: Wichtige Formeln zur Vektoranalysis
Date: 2013-11-11 16:10
Category: Maths
Tags: maths, vectoranalysis, differentialequations
Author: x4343
Summary: Vektoranalysis

# #1: Ebene und räumliche Kurven

## 1.1 Vektorielle Darstellung einer Kurve

Darstellung einer Kurve durch einen parameterabhängigen Ortsvektor

Ortsvektor einer ebenen Kurve:

$ \overrightarrow{r}(t) = x(t) \overrightarrow{e}_x + y(t) \overrightarrow{e}_y = \left( \begin{array}{c} x(t) \\ y(t) \end{array} \right) $

Ortsvektor einer Raumkurve

$ \overrightarrow{r}(t) = x(t) \overrightarrow{e}_x + y(t) \overrightarrow{e}_y + z(t) \overrightarrow{e}_z = \left( \begin{array}{c} x(t) \\\ y(t) \\\ z(t) \end{array} \right) $

## 1.2 Differentiation eines Vektors nach einem Parameter

Tangentenvektor einer ebenen Kurve

$ \dot{\overrightarrow{r}}(t) = \dot{x}(t) \overrightarrow{e}_x + \dot{y}(t) \overrightarrow{e}_y = \left( \begin{array}{c} \dot{x}(t) \\\ \dot{y}(t) \end{array} \right)$

Tangentenvektor einer Raumkurve

$ \dot{\overrightarrow{r}}(t) = \dot{x}(t) \overrightarrow{e}_x + \dot{y}(t) \overrightarrow{e}_y + \dot{z}(t) \overrightarrow{e}_z = \left( \begin{array}{c} \dot{x}(t) \\\ \dot{y}(t) \\\ \dot{z}_t\end{array} \right) $

Wobei $ \dot{\overrightarrow{r}}(t) = \frac{d\overrightarrow{r}}{dt}$ die 1. Ableitung des Ortsvektors $\overrightarrow{r} = \overrightarrow{r}(t)$ nacht dem Paramter $t$ ist.

Ableitungsregeln für Summen und Produkte von Vektoren

Summenregel:

$\frac{d}{dt}(\overrightarrow{a}+\overrightarrow{b}) = \dot{\overrightarrow{a}} + \dot{\overrightarrow{b}}$

Produktregel für ein Skalarprodukt:

$\frac{d}{dt}(\overrightarrow{a} \cdot \overrightarrow{b}) = \dot{\overrightarrow{a}} \cdot \overrightarrow{b} + \overrightarrow{a} \cdot \dot{\overrightarrow{b}}$

Produktregel für ein Vektorprodukt:

$\frac{d}{dt}(\overrightarrow{a} \times \overrightarrow{b}) = \dot{\overrightarrow{a}} \times \overrightarrow{b} + \overrightarrow{a} \times {\overrightarrow{b}}$

Für ein Produkt aus einer skalaren und einer Vektorfunktion gilt:

$ \frac{d}{dt} (\phi\overrightarrow{a}) = \dot{\phi}\overrightarrow{a} + \phi\dot{\overrightarrow{a}} $

Geschwindigkeitsvektor (1. Ableitung des Ortsvektors nach der Zeit):

$ \overrightarrow{v}(t) = \dot{\overrightarrow{r}(t)}$

Beschleunigungsvektor (2. Ableitung des Ortsvektors nach der Zeit):

$ \overrightarrow{a}(t) = \dot{\overrightarrow{v}(t)} = \ddot{\overrightarrow{r}(t)} $

## 1.3 Bogenlänge

Bogenlänge einer ebenen Kurve:

$ s = \int_{t_1}^{t_2} | \dot{\overrightarrow{r}} dt | = \int_{t_1}^{t_2} \sqrt{\dot{x}^2 + \dot{y}^2} dt$

Bogenlänge einer Raumkurve:

$ s = \int_{t_1}^{t_2} | \dot{\overrightarrow{r}} dt | = \int_{t_1}^{t_2} \sqrt{\dot{x}^2 + \dot{y}^2 + \dot{z}^2} dt$

## 1.4 Tangenten- und Hauptnormaleneinheitsvektor

Tangenteneinheitsvektor:

$ \overrightarrow{T} \frac{\dot{\overrightarrow{r}}}{|\dot{\overrightarrow{r}}|} = \frac{1}{|\dot{\overrightarrow{r}}|} \dot{\overrightarrow{r}} $ mit $|\overrightarrow{T}| = 1$

Hauptnormaleneinheitsvektor

$ \overrightarrow{N} \frac{\dot{\overrightarrow{T}}}{|\dot{\overrightarrow{T}}|} = \frac{1}{|\dot{\overrightarrow{T}}|} \dot{\overrightarrow{T}} $ mit $|\overrightarrow{N}| = 1$

$\overrightarrow{N}$ zeigt in Richtung der Kurvenkrümmung.

## 1.5 Krümmung einer Kurve

Krümmung einer Raumkurve $\overrightarrow{r} = \overrightarrow{r}(s))$ (s: Bogenlänge)

$ \kappa |\frac{d\overrightarrow{T}}{ds}| = |\dot{\overrightarrow{T}}(s)|  $

Krümmung einer Raumkurve $\overrightarrow{r} = \overrightarrow{r}(t)$ (t: belieb. Param.)

$ \kappa = \frac{|\dot{\overrightarrow{r}}| \times \ddot{\overrightarrow{r}}}{|\dot{\overrightarrow{r}}|^3} \forall \dot{\overrightarrow{r}} \not 0$

## 1.6 Tangential- und Normalkomponenten

Am Beispiel des Geschwindigkeitsvektors:

$ \overrightarrow{v} = v_T \overrightarrow{T} + v_N \overrightarrow{N} = v \overrightarrow{T} + 0 \overrightarrow{N} = v \overrightarrow{T}$

... des Beschleunigungsvektors

$ \overrightarrow{a} = a_T \overrightarrow{T} + a_N \overrightarrow{N} =  \dot{\overrightarrow{v}} \overrightarrow{T} + \frac{v^2}{\varrho} \overrightarrow{N} = \dot{\overrightarrow{v}} + \kappa v^2 \overrightarrow{N} $

# #2: Flächen im Raum


# #3: Skalar- und Vektorfelder


# #4: Gradient eines Skalarfeldes


# #5: Divergenz und Rotation eines Vektorfeldes


# #6: Koordinatensysteme


# #7: Linien- und Kurvenintegrale


# #8: Oberflächenintegrale


# #9: Integralsätze von Gauß und Stokes


# Useful Linkx
 
